@echo off
gradle assembleDebug
pause
