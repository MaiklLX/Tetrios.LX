# BlockDrop: Neon Roguelite

A fresh native Android starter project for a neon-styled falling-block roguelite.

## Build
Run the GitHub Actions workflow **Build BlockDrop APK** (`workflow_dispatch`) or push to `main`.
The workflow runs `gradle assembleDebug` and publishes the APK as an Actions artifact.

## Included in this starter
- Native Android Java app, portrait orientation
- Falling-block gameplay with increasing stages and a capped fall-speed curve
- Stage upgrade choice overlay (shield, chrono/slow-time, salvage currency)
- Touch controls: move, soft drop, rotate, hard drop, shield, freeze, line clear, rewind
- Neon visual style and simple persistent-on-run currency/stage display

## Important
This is a fresh playable starter, not a fully balanced release. The meta-progression is currently a run-level prototype (currency and upgrade choices are not yet saved permanently between app launches). The shield/rewind/freeze mechanics are prototype-level and should be tested and refined before release.
