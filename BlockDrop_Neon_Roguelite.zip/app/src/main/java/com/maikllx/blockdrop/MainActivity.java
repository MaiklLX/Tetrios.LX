package com.maikllx.blockdrop;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import android.content.Context;
import android.os.Handler;
import java.util.*;

public class MainActivity extends Activity {
    GameView game;
    @Override public void onCreate(Bundle b) { super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(7,8,24)); getWindow().setNavigationBarColor(Color.rgb(7,8,24)); game=new GameView(this); setContentView(game); }

    class GameView extends View {
        final int COLS=10, ROWS=20;
        int[][] board=new int[ROWS][COLS];
        int[] palette={0,Color.rgb(0,245,255),Color.rgb(255,40,220),Color.rgb(154,92,255),Color.rgb(255,210,60),Color.rgb(60,255,150),Color.rgb(255,100,65),Color.rgb(90,145,255)};
        int[][][] shapes={
          {{1,1,1,1}},{{1,1},{1,1}},{{0,1,0},{1,1,1}},{{1,0,0},{1,1,1}},{{0,0,1},{1,1,1}},{{0,1,1},{1,1,0}},{{1,1,0},{0,1,1}}
        };
        int[][] piece; int px=3,py=0, color=1; int lines=0, stage=1, coins=0, shield=0, frozen=0, rewinds=0;
        int fallMs=650; boolean over=false, paused=false, choosing=false; String message=""; String[] upgrades={"NEON CORE","CHRONO FIELD","SALVAGE"}; Random rng=new Random();
        Paint p=new Paint(3); Handler h=new Handler(); long last=0; float cell=0, left=0, top=0;
        Runnable tick=new Runnable(){public void run(){ if(!over&&!paused&&!choosing){ if(System.currentTimeMillis()-last>=fallMs){stepDown();last=System.currentTimeMillis();} invalidate(); h.postDelayed(this,45);} }};
        GameView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);spawn();h.post(tick);}
        void spawn(){int k=rng.nextInt(shapes.length); piece=copy(shapes[k]); color=1+rng.nextInt(7); px=3;py=0;if(collides(px,py,piece)){over=true;message="SYSTEM FAILURE";}}
        int[][] copy(int[][] a){int[][] b=new int[a.length][];for(int i=0;i<a.length;i++)b[i]=a[i].clone();return b;}
        boolean collides(int x,int y,int[][] s){for(int r=0;r<s.length;r++)for(int c=0;c<s[r].length;c++)if(s[r][c]!=0){int xx=x+c,yy=y+r;if(xx<0||xx>=COLS||yy>=ROWS)return true;if(yy>=0&&board[yy][xx]!=0)return true;}return false;}
        void stepDown(){if(!collides(px,py+1,piece))py++;else lock();}
        void lock(){for(int r=0;r<piece.length;r++)for(int c=0;c<piece[r].length;c++)if(piece[r][c]!=0&&py+r>=0)board[py+r][px+c]=color;
          int cleared=0;for(int r=ROWS-1;r>=0;r--){boolean full=true;for(int c=0;c<COLS;c++)if(board[r][c]==0){full=false;break;}if(full){cleared++;for(int y=r;y>0;y--)board[y]=board[y-1].clone();board[0]=new int[COLS];r++;}}
          if(cleared>0){lines+=cleared;coins+=cleared*5; if(lines>=stage*5){stage++;coins+=10;choosing=true;message="STAGE "+stage+"  •  CHOOSE UPGRADE";} }
          fallMs=Math.max(180,650-(stage-1)*22);spawn();}
        void rotate(){int h=piece.length,w=piece[0].length;int[][] n=new int[w][h];for(int r=0;r<h;r++)for(int c=0;c<w;c++)n[c][h-1-r]=piece[r][c];if(!collides(px,py,n))piece=n;}
        void clearBottom(){for(int r=ROWS-1;r>=Math.max(0,ROWS-4);r--)board[r]=new int[COLS];coins+=8;message="LINE CLEAR +8";}
        void rewind(){if(rewinds>0){rewinds--;for(int r=0;r<ROWS;r++)board[r]=new int[COLS];py=0;message="TIMELINE RESTORED";}else message="NO REWIND CHARGES";}
        void choose(int n){choosing=false;if(n==0){shield++;message="SHIELD CHARGED";}else if(n==1){fallMs=Math.min(900,fallMs+100);frozen=1;message="CHRONO FIELD: SLOW TIME";}else{coins+=20;message="SALVAGE +20";}invalidate();}
        void drawText(Canvas c,String s,float x,float y,float size,int col){p.setColor(col);p.setTextSize(size);p.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD));c.drawText(s,x,y,p);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);c.drawColor(Color.rgb(7,8,24));float W=getWidth(),H=getHeight();p.setShader(new LinearGradient(0,0,W,H,Color.rgb(18,12,48),Color.rgb(5,20,35),Shader.TileMode.CLAMP));c.drawRect(0,0,W,H,p);p.setShader(null);
          drawText(c,"BLOCKDROP",24,48,32,Color.rgb(0,245,255));drawText(c,"NEON ROGUELITE  /  RUN "+stage,24,76,15,Color.rgb(255,50,220));drawText(c,"LINES "+lines+"    ◆ "+coins,24,104,16,Color.WHITE);
          cell=Math.min((W-36)/COLS,(H-260)/ROWS);left=(W-COLS*cell)/2;top=125;
          p.setColor(Color.argb(170,9,15,34));c.drawRoundRect(left-5,top-5,left+COLS*cell+5,top+ROWS*cell+5,12,12,p);
          for(int r=0;r<ROWS;r++)for(int x=0;x<COLS;x++){int v=board[r][x];drawCell(c,left+x*cell,top+r*cell,cell,v==0?Color.rgb(22,29,53):palette[v],v==0);}
          if(!over&&!choosing)for(int r=0;r<piece.length;r++)for(int x=0;x<piece[r].length;x++)if(piece[r][x]!=0)drawCell(c,left+(px+x)*cell,top+(py+r)*cell,cell,palette[color],false);
          float cy=top+ROWS*cell+28;drawText(c,"TAP CONTROLS",24,cy,14,Color.rgb(160,170,210));
          String[] controls={"◀","▼","ROTATE","DROP","SHIELD","FREEZE","CLEAR","REWIND"};
          float bw=(W-44)/4;for(int i=0;i<8;i++){int row=i/4,col=i%4;float x=22+col*(bw+0), y=cy+12+row*55;p.setColor(Color.rgb(19,27,55));c.drawRoundRect(x,y,x+bw-5,y+44,10,10,p);drawText(c,controls[i],x+8,y+28,controls[i].length()>5?12:17,palette[(i%7)+1]);}
          if(choosing){overlay(c,W,H,"STAGE CLEAR","CHOOSE ONE UPGRADE",new String[]{"1  SHIELD  •  BLOCK A HIT","2  CHRONO  •  SLOW FALL","3  SALVAGE  •  +20 COINS"});}
          if(over)overlay(c,W,H,"SYSTEM FAILURE","RUN ENDED  •  TAP TO REBOOT",new String[]{"TAP ANYWHERE TO RESTART"});
          if(!message.isEmpty()){drawText(c,message,24,H-18,14,Color.rgb(255,210,70));}
        }
        void drawCell(Canvas c,float x,float y,float s,int col,boolean empty){p.setColor(col);p.setStyle(Paint.Style.FILL);c.drawRoundRect(x+1,y+1,x+s-2,y+s-2,4,4,p);if(!empty){p.setColor(Color.WHITE);p.setAlpha(65);c.drawRoundRect(x+3,y+3,x+s-5,y+s*.25f,3,3,p);p.setAlpha(255);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.5f);p.setColor(col);c.drawRoundRect(x+1,y+1,x+s-2,y+s-2,4,4,p);p.setStyle(Paint.Style.FILL);}}
        void overlay(Canvas c,float w,float h,String title,String sub,String[] opts){p.setColor(Color.argb(225,5,8,25));c.drawRoundRect(18,h*.34f,w-18,h*.66f,20,20,p);drawText(c,title,35,h*.40f,25,Color.rgb(0,245,255));drawText(c,sub,35,h*.44f,13,Color.WHITE);for(int i=0;i<opts.length;i++)drawText(c,opts[i],35,h*.49f+i*28,13,Color.rgb(255,70,220));}
        @Override public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;float x=e.getX(),y=e.getY(),cy=top+ROWS*cell+40;
          if(over){board=new int[ROWS][COLS];lines=0;stage=1;coins=0;fallMs=650;over=false;message="NEW RUN";spawn();invalidate();return true;}
          if(choosing){int n=y>getHeight()*.56f?2:y>getHeight()*.52f?1:0;if(y<getHeight()*.49f)n=0;choose(n);return true;}
          if(y>cy+4&&y<cy+130){int col=(int)((x-22)/((getWidth()-44)/4));int row=y>cy+65?1:0;int idx=row*4+Math.max(0,Math.min(3,col));switch(idx){case 0:if(!collides(px-1,py,piece))px--;break;case 1:stepDown();break;case 2:rotate();break;case 3:while(!collides(px,py+1,piece))py++;stepDown();break;case 4:if(shield>0){shield--;message="SHIELD USED";}else message="NO SHIELD";break;case 5:frozen=1;fallMs=Math.min(900,fallMs+120);message="FREEZE FIELD";break;case 6:clearBottom();break;case 7:rewind();break;}invalidate();return true;}
          if(x<getWidth()/2){if(!collides(px-1,py,piece))px--;}else rotate();invalidate();return true;}
    }
}
