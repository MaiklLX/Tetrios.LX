# Block Buddies Android APK project

This is a native Android shell that packages the self-contained HTML game inside an Android WebView. It keeps the web game's UI, character selection, touch controls, sounds and local browser storage in the APK.

## Build an APK with GitHub Actions
1. Upload the *contents* of this archive into the root of your GitHub repository, preserving folders (`app/`, `.github/`, `build.gradle`, `settings.gradle`, etc.). Do not upload only the ZIP.
2. Commit the files to branch `main`.
3. Open **Actions → Build Block Buddies APK → Run workflow** (or wait for the push-triggered run).
4. Open the completed workflow run and download artifact **Block-Buddies-debug-apk**.
5. Extract that artifact ZIP and install `app-debug.apk` on your Android phone. Android may ask you to allow installation from that source.

## Edit the game
Main game HTML: `app/src/main/assets/index.html`. The Android wrapper is `app/src/main/java/com/maikllx/blockbuddies/MainActivity.java`.

## Note
This is a debug APK build workflow, not a Play Store release/signing pipeline. The game saves local progress in WebView storage on the device; it is not cloud-synced. Test gameplay and audio on the target phone after building.
